
export class noteComponent {
	constructor(
		public id: number = null,
    	public author: string = "",
    	public text: string = "",
    	){}
}
