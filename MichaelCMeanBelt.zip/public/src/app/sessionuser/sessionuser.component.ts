export class SessionuserComponent {
	constructor(
    	public username: string = "",
  	){}
}
